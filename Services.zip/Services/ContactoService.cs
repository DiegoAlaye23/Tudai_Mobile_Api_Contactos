using GestionContactosApi.Models;

namespace GestionContactosApi.Services
{
    public class ContactoService
    {
        private readonly List<Contacto> _contactos;

        public ContactoService()
        {
            _contactos = new List<Contacto>
            {
                new Contacto { Id = 1, Nombre = "Diego", Apellido = "Alaye", Telefono = "2494511560", Domicilio ="San Lorenzo 1280", Genero ="Masculino" },
                new Contacto { Id = 2, Nombre = "Pepito", Apellido = "Gonzalez", Telefono = "2491542565", Domicilio = "calle falsa123", Genero ="Masculino"}
            };
        }

        public List<Contacto> ObtenerTodos()
        {
            return _contactos;
        }

        public Contacto? ObtenerPorId(int id)
        {
            return _contactos.FirstOrDefault(c => c.Id == id);
        }

        public void Agregar(Contacto contacto)
        {
            _contactos.Add(contacto);
        }

        public bool Eliminar(int id)
        {
            var contacto = ObtenerPorId(id);
            if (contacto != null)
            {
                _contactos.Remove(contacto);
                return true;
            }
            return false;
        }
    }
}
